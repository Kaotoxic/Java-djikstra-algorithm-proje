import java.util.*;

public class DijkstraOrnegi {

    public static void main(String[] args) {
        Scanner tarayıcı = new Scanner(System.in);

        System.out.print("Kaç nokta var? ");
        int n = tarayıcı.nextInt();


        int[][] mesafeler = new int[n][n];


        System.out.println("Lütfen noktalar arasındaki mesafeleri girin:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i != j) {
                    System.out.print("Nokta " + (i + 1) + " ile " + (j + 1) + " arası mesafe: ");
                    mesafeler[i][j] = tarayıcı.nextInt();
                } else {

                    mesafeler[i][j] = 0;
                }
            }
        }

        System.out.print("Başlangıç noktasını girin: ");
        int başlangıç = tarayıcı.nextInt();
        System.out.print("Hedef noktasını girin: ");
        int hedef = tarayıcı.nextInt();

        int enKısaMesafe = dijkstra(mesafeler, başlangıç - 1, hedef - 1);

        if (enKısaMesafe == Integer.MAX_VALUE) {
            System.out.println("Başlangıç ve hedef noktalar arasında bir yol bulunamadı.");
        } else {
            System.out.println("Başlangıç ve hedef noktalar arasındaki en kısa mesafe: " + enKısaMesafe);
        }

        tarayıcı.close();
    }


    private static int dijkstra(int[][] graf, int başlangıç, int hedef) {
        int n = graf.length;
        int[] mesafeler = new int[n];
        boolean[] ziyaretEdildi = new boolean[n];

        Arrays.fill(mesafeler, Integer.MAX_VALUE);
        mesafeler[başlangıç] = 0;

        for (int i = 0; i < n - 1; i++) {
            int minIndex = -1;
            int minMesafe = Integer.MAX_VALUE;

            for (int j = 0; j < n; j++) {
                if (!ziyaretEdildi[j] && mesafeler[j] < minMesafe) {
                    minIndex = j;
                    minMesafe = mesafeler[j];
                }
            }

            if (minIndex == -1) {
                break;
            }

            ziyaretEdildi[minIndex] = true;

            for (int j = 0; j < n; j++) {
                if (!ziyaretEdildi[j] && graf[minIndex][j] != 0 && mesafeler[minIndex] != Integer.MAX_VALUE &&
                        mesafeler[minIndex] + graf[minIndex][j] < mesafeler[j]) {
                    mesafeler[j] = mesafeler[minIndex] + graf[minIndex][j];
                }
            }
        }

        return mesafeler[hedef];
    }
}
